import React from "react";
import DefaultLayout from "@/components/Layouts/DefaultLayout";
import AgentsTable from "@/components/Tables/AgentsTable";

const page = () => {
  return (
    <DefaultLayout>
      <AgentsTable />
    </DefaultLayout>
  );
};

export default page;
