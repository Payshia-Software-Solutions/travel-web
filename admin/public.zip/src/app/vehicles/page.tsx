import React from 'react'
import DefaultLayout from "@/components/Layouts/DefaultLayout";
import VehicleTable from '@/components/Tables/VehiclesTable';

const VehiclesPage = () => {
  return (
    <DefaultLayout>
      <VehicleTable/>
    </DefaultLayout>
  );
}

export default VehiclesPage