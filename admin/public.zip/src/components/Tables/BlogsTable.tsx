import Breadcrumb from "../Breadcrumbs/Breadcrumb";
import { BLOGS } from "@/types/blogs";



const packageData: BLOGS[] = [
  {
    no: 1,
    title: "Scenic Hill Country Train Ride",
    description:
      "Experience the breathtaking beauty of Sri Lanka's hill country as you journey by train through lush tea plantations and misty landscapes.",
    publishDate: "2023-03-22",
    editDate: 'null',
  },
  {
    no: 2,
    title: "Coastal Train Adventure",
    description:
      "Enjoy the stunning coastal views and salty breeze as you ride along the scenic train route hugging Sri Lanka's southern coastline.",
    publishDate: "2023-03-20",
    editDate: "2023-03-21",
  },
  {
    no: 3,
    title: "Historical Train Tour: Colombo to Galle",
    description:
      "Step back in time and explore the rich history of Sri Lanka's southern coast with this train tour from Colombo to the historic city of Galle, passing by ancient forts and charming coastal towns.",
    publishDate: "2023-03-18",
    editDate: 'null',
  },
  {
    no: 4,
    title: "Jungle Train Expedition: Colombo to Badulla",
    description:
      "Embark on an adventurous journey through dense jungles and picturesque landscapes on this train ride from Colombo to Badulla, immersing yourself in the natural beauty of Sri Lanka's interior.",
    publishDate: "2023-03-25",
    editDate: 'null',
  },
  {
    no: 5,
    title: "Cultural Train Safari: Colombo to Kandy",
    description:
      "Discover the cultural heart of Sri Lanka on this train safari from Colombo to Kandy, passing by ancient temples, lush forests, and charming villages along the way.",
    publishDate: "2023-03-24",
    editDate: "2023-03-24",
  },
];

const MAX_DESCRIPTION_WORDS = 5; // Maximum number of words for description

const truncateDescription = (description: string) => {
    // Split the description into words
    const words = description.split(" ");
    // Join the first MAX_DESCRIPTION_WORDS words
    const truncatedDescription = words.slice(0, MAX_DESCRIPTION_WORDS).join(" ");
    // If the original description is longer than the maximum word count, add ellipsis
    if (words.length > MAX_DESCRIPTION_WORDS) {
        return truncatedDescription + "...";
    } else {
        return truncatedDescription;
    }
};

const BlogsTable = () => {
    
  return (
    <div>
      <Breadcrumb
        pageName="Listed Blog Posts"
        pageDesc="Find out the status of your bookings"
        btnName="+ New Post"
      />
      <div className="rounded-sm border border-stroke bg-white px-5 pb-2.5 pt-6 shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5 xl:pb-1">
        <div className="max-w-full overflow-x-auto">
          <table className="w-full table-auto">
            <thead>
              <tr className="bg-gray-2 text-left dark:bg-meta-4">
                <th className="min-w-[100px] px-4 py-4 font-medium text-black dark:text-white xl:pl-11">
                  #
                </th>
                <th className="min-w-[80px] px-4 py-4 font-medium text-black dark:text-white">
                  TITLE
                </th>
                <th className="min-w-[180px] px-4 py-4 font-medium text-black dark:text-white">
                  DESCRIPTION
                </th>
                <th className="px-4 py-4 font-medium text-black dark:text-white">
                  PUBLISHED
                </th>
                <th className="px-4 py-4 font-medium text-black dark:text-white">
                  EDITED
                </th>
                <th className="px-4 py-4 font-medium text-black dark:text-white">
                  {/* VIEW */}
                </th>
              </tr>
            </thead>
            <tbody>
              {packageData.map((packageItem, key) => (
                <tr key={key}>
                  <td className="border-b border-[#eee] px-4 py-5  dark:border-strokedark xl:pl-11">
                    <h5 className="font-medium text-black dark:text-white">
                      {packageItem.no}
                    </h5>
                  </td>
                  <td className="border-b border-[#eee] px-4 py-5 dark:border-strokedark">
                    <p className="text-black dark:text-white">
                      {packageItem.title}
                    </p>
                  </td>
                  <td className="border-b border-[#eee] px-4 py-5 dark:border-strokedark">
                    <p className="text-black dark:text-white">
                      {truncateDescription(packageItem.description)}
                    </p>
                  </td>
                  <td className="border-b border-[#eee] px-4 py-5 dark:border-strokedark">
                    <p className="text-black dark:text-white">
                      {packageItem.publishDate}
                    </p>
                  </td>
                  <td className="border-b border-[#eee] px-4 py-5 dark:border-strokedark">
                    <p className="text-black dark:text-white">
                      {packageItem.editDate}
                    </p>
                  </td>
                  <td className="border-b border-[#eee] px-4 py-5 dark:border-strokedark">
                    <p className="cursor-pointer text-black underline hover:text-blue-700 dark:text-white">
                      view
                    </p>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BlogsTable;
