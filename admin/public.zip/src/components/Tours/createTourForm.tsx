import { useState, ChangeEvent, FormEvent } from "react";
import { Tour } from "@/types/tours";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import config from "@/config"; // Adjust the import path as necessary
import FloatingLabelInput from "../Input";

interface CreateTourFormProps {
  onTourCreated: (newTour: Tour) => void;
}

const CreateTourForm: React.FC<CreateTourFormProps> = ({ onTourCreated }) => {
  const [tourData, setTourData] = useState<Tour>({
    tourId: "",
    highlightText: "",
    tourName: "",
    tourDetails: "",
    tourGallery: [],
    participants: 0,
    tourPrice: 0,
    aboutThisTour: "",
    noOfDays: 0,
    tourSchedule: [],
    tourCover: "",
    aboutCover: "",
    tags: "",
    tourCategory: "",
    createdBy: "",
    updatedBy: "",
    isActive: 1, // Assuming 1 means active
  });

  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setTourData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  console.log(`${config.API_BASE_URL}/tours`);
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(`${config.API_BASE_URL}/tours`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(tourData),
      });

      if (!response.ok) {
        const errorMessage = await response.text();
        console.error(
          "Error:",
          response.status,
          response.statusText,
          errorMessage,
        );
        throw new Error("Network response was not ok");
      }

      const newTour = await response.json();
      onTourCreated(newTour);
      toast.success("Tour created successfully!");
    } catch (error) {
      console.error("Error creating tour:", error);
      toast.error("Failed to create tour. Please try again." + error);
    }
  };

  return (
    <div className="rounded-lg bg-white lg:col-span-3 lg:p-12">
      <div className="mb-4 border-b border-gray">
        <h1 className="text-3xl font-extrabold text-black-2">Tour Info</h1>
        <p>Fill all required fields</p>
      </div>

      <form action="#" className="space-y-6" onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {/* Tour Name */}
          <FloatingLabelInput
            id="tourName"
            name="tourName"
            placeholder="Name"
            value={tourData.tourName}
            onChange={handleChange}
          />

          {/* Highlight Text */}
          <FloatingLabelInput
            id="highlightText"
            name="highlightText"
            placeholder="Highlight Text"
            value={tourData.highlightText}
            onChange={handleChange}
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-1 md:grid-cols-3">
          {/* Participants */}
          <FloatingLabelInput
            id="participants"
            name="participants"
            placeholder="Participants"
            value={tourData.participants === 0 ? "" : tourData.participants}
            onChange={handleChange}
          />

          {/* Tour Price */}
          <FloatingLabelInput
            id="tourPrice"
            name="tourPrice"
            type="number"
            placeholder="Tour Price"
            value={tourData.tourPrice === 0 ? "" : tourData.participants}
            onChange={handleChange}
          />

          {/* No of Days */}
          <FloatingLabelInput
            id="noOfDays"
            name="noOfDays"
            type="number"
            placeholder="No of Days"
            value={tourData.noOfDays === 0 ? "" : tourData.noOfDays}
            onChange={handleChange}
          />
        </div>

        {/* About Text Box */}
        <div className="relative">
          <textarea
            className="peer w-full rounded-lg border-2 border-stroke bg-transparent p-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-0"
            placeholder=" "
            id="aboutThisTour"
            onChange={handleChange}
            name="aboutThisTour"
            rows={5}
          />
          <label
            htmlFor="aboutThisTour"
            className="peer-focus:text-gray-600 absolute left-3 top-3 z-10 origin-[0] -translate-y-6 scale-75 transform bg-white px-2 text-sm font-bold text-black duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:px-2 peer-focus:text-sm"
          >
            About This Tour
          </label>
        </div>

        {/* Tour Details Text Box */}
        <div className="relative">
          <textarea
            className="peer w-full rounded-lg border-2 border-stroke bg-transparent p-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-0"
            placeholder=" "
            id="tourDetails"
            onChange={handleChange}
            name="tourDetails"
            rows={5}
          />
          <label
            htmlFor="tourDetails"
            className="peer-focus:text-gray-600 absolute left-3 top-3 z-10 origin-[0] -translate-y-6 scale-75 transform bg-white px-2 text-sm font-bold text-black duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:px-2 peer-focus:text-sm"
          >
            Tour Details
          </label>
        </div>

        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            className="inline-block w-full rounded-lg bg-black px-5 py-3 font-medium text-white sm:w-auto"
          >
            Save
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateTourForm;
