export type Lead = {
  avatar: string;
  name: string;
  email: string;
  project: string;
  duration: number;
  status: string;
};
