export type AGENTS = {
  no: number;
  name: string;
  country: string;
  address: string;
  contactNo: string;

};
