export type BLOGS = {
  no: number;
  title: string;
  description: string;
  publishDate: string;
  editDate: string;
  
};
