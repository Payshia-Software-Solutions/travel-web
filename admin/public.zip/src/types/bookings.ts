export type BOOKING = {
    id: number;
    tour: string;
    name: string;
    totDistance: number;
    days: number;
    status: string;
  };
  