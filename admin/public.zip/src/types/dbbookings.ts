export type DBBOOKINGS = {
    tour: string;
    name: string;
    status: string;
  };
  