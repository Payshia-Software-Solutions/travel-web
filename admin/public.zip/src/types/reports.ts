export type Reports = {
    id: number;
    title: string;
    desc: string;
    date: string;
  };
  