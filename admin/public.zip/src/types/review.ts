export type Reviews = {
    id: number;
    name: string;
    country: string;
    review: string;
  };
  