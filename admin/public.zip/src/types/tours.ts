export interface DayPlan {
  day: number;
  title: string;
  description: string;
}

export interface Tour {
  tourId:string;
  highlightText: string;
  tourName: string;
  tourDetails: string;
  tourGallery: string[];
  participants: number;
  tourPrice: number;
  aboutThisTour: string;
  noOfDays: number;
  tourSchedule: DayPlan[];
  tourCover: string;
  aboutCover: string;
  tags: string;
  tourCategory:string;
  createdBy:string;
  updatedBy:string;
  isActive:number;
}
