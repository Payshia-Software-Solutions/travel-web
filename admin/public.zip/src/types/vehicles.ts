export type VEHICLE = {
    id: number;
    type: string;
    owner: string;
    vehicleNo: string;
    seats: number;
    availabilty: string;
  };
  