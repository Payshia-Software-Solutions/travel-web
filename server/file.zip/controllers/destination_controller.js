const Destination = require("../models/Destination");

// @desc Create a destination
// @route POST /api/destinations
// @access Public
exports.createDestination = async (req, res) => {
  try {
    const { name, description, location, imageUrl } = req.body;

    if (!name || !description || !location || !imageUrl) {
      return res.status(400).json({ msg: "Please include all fields" });
    }

    const newDestination = new Destination({
      name,
      description,
      location,
      imageUrl,
    });

    const destination = await newDestination.save();
    res.json(destination);
  } catch (err) {
    console.error("Server Error:", err.message);
    res.status(500).send("Server Error");
  }
};

// @desc Get all destinations
// @route GET /api/destinations
// @access Public
exports.getDestinations = async (req, res) => {
  try {
    const destinations = await Destination.find();
    res.json(destinations);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
};

// @desc Get destination by ID
// @route GET /api/destinations/:id
// @access Public
exports.getDestinationById = async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.id);
    if (!destination) {
      return res.status(404).json({ msg: "Destination not found" });
    }
    res.json(destination);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Destination not found" });
    }
    res.status(500).send("Server Error");
  }
};

// @desc Update a destination
// @route PUT /api/destinations/:id
// @access Public
exports.updateDestination = async (req, res) => {
  try {
    const { name, description, location, imageUrl } = req.body;

    const updatedDestination = await Destination.findByIdAndUpdate(
      req.params.id,
      { name, description, location, imageUrl },
      { new: true }
    );

    if (!updatedDestination) {
      return res.status(404).json({ msg: "Destination not found" });
    }

    res.json(updatedDestination);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Destination not found" });
    }
    res.status(500).send("Server Error");
  }
};

// @desc Delete a destination
// @route DELETE /api/destinations/:id
// @access Public
exports.deleteDestination = async (req, res) => {
  try {
    const destination = await Destination.findByIdAndDelete(req.params.id);

    if (!destination) {
      return res.status(404).json({ msg: "Destination not found" });
    }

    res.json({ msg: "Destination removed" });
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Destination not found" });
    }
    res.status(500).send("Server Error");
  }
};
