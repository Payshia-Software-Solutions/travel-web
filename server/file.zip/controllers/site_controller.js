const Site = require("../models/Site");

// @desc Create a site
// @route POST /api/sites
// @access Public
exports.createSite = async (req, res) => {
  try {
    const { name, description, location, url } = req.body;

    if (!name || !description || !location || !url) {
      return res.status(400).json({ msg: "Please include all fields" });
    }

    const newSite = new Site({
      name,
      description,
      location,
      url,
    });

    const site = await newSite.save();
    res.json(site);
  } catch (err) {
    console.error("Server Error:", err.message);
    res.status(500).send("Server Error");
  }
};

// @desc Get all sites
// @route GET /api/sites
// @access Public
exports.getSites = async (req, res) => {
  try {
    const sites = await Site.find();
    res.json(sites);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
};

// @desc Get site by ID
// @route GET /api/sites/:id
// @access Public
exports.getSiteById = async (req, res) => {
  try {
    const site = await Site.findById(req.params.id);
    if (!site) {
      return res.status(404).json({ msg: "Site not found" });
    }
    res.json(site);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Site not found" });
    }
    res.status(500).send("Server Error");
  }
};

// @desc Update a site
// @route PUT /api/sites/:id
// @access Public
exports.updateSite = async (req, res) => {
  try {
    const { name, description, location, url } = req.body;

    const updatedSite = await Site.findByIdAndUpdate(
      req.params.id,
      { name, description, location, url },
      { new: true }
    );

    if (!updatedSite) {
      return res.status(404).json({ msg: "Site not found" });
    }

    res.json(updatedSite);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Site not found" });
    }
    res.status(500).send("Server Error");
  }
};

// @desc Delete a site
// @route DELETE /api/sites/:id
// @access Public
exports.deleteSite = async (req, res) => {
  try {
    const site = await Site.findByIdAndDelete(req.params.id);

    if (!site) {
      return res.status(404).json({ msg: "Site not found" });
    }

    res.json({ msg: "Site removed" });
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Site not found" });
    }
    res.status(500).send("Server Error");
  }
};
