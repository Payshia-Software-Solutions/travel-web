const Tour = require("../models/Tour");

// Create a tour
exports.createTour = async (req, res) => {
  try {
    const {
      highlightText,
      name,
      description,
      tourImages,
      participantCount,
      totalPrice,
      aboutThisTour,
      noOfDays,
      dayPlan,
    } = req.body;

    if (
      !highlightText ||
      !name ||
      !description ||
      !tourImages ||
      !participantCount ||
      !totalPrice ||
      !aboutThisTour ||
      !noOfDays ||
      !dayPlan
    ) {
      return res.status(400).json({ msg: "Please include all fields" });
    }

    const newTour = new Tour({
      highlightText,
      name,
      description,
      tourImages,
      participantCount,
      totalPrice,
      aboutThisTour,
      noOfDays,
      dayPlan,
    });

    const tour = await newTour.save();
    res.json(tour);
  } catch (err) {
    console.error("Server Error:", err.message);
    res.status(500).send("Server Error");
  }
};

// Get all tours
exports.getAllTours = async (req, res) => {
  try {
    const tours = await Tour.find();
    res.json(tours);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
};

// Get a tour by ID
exports.getTourById = async (req, res) => {
  try {
    const tour = await Tour.findById(req.params.id);
    if (!tour) {
      return res.status(404).json({ msg: "Tour not found" });
    }
    res.json(tour);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Tour not found" });
    }
    res.status(500).send("Server Error");
  }
};

// Update a tour
exports.updateTour = async (req, res) => {
  try {
    const {
      highlightText,
      name,
      description,
      tourImages,
      participantCount,
      totalPrice,
      aboutThisTour,
      noOfDays,
      dayPlan,
    } = req.body;

    const updatedTour = await Tour.findByIdAndUpdate(
      req.params.id,
      {
        highlightText,
        name,
        description,
        tourImages,
        participantCount,
        totalPrice,
        aboutThisTour,
        noOfDays,
        dayPlan,
      },
      { new: true }
    );

    if (!updatedTour) {
      return res.status(404).json({ msg: "Tour not found" });
    }

    res.json(updatedTour);
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Tour not found" });
    }
    res.status(500).send("Server Error");
  }
};

// Delete a tour
exports.deleteTour = async (req, res) => {
  try {
    const tour = await Tour.findByIdAndDelete(req.params.id);

    if (!tour) {
      return res.status(404).json({ msg: "Tour not found" });
    }

    res.json({ msg: "Tour removed" });
  } catch (err) {
    console.error(err.message);
    if (err.kind === "ObjectId") {
      return res.status(404).json({ msg: "Tour not found" });
    }
    res.status(500).send("Server Error");
  }
};
