const mongoose = require("mongoose");

const DayPlanSchema = new mongoose.Schema({
    day: {
        type: Number,
        required: true,
    },
    title: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
});

const TourSchema = new mongoose.Schema({
    highlightText: {
        type: String,
        required: true,
    },
    name: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    tourImages: [{
        type: String,
        required: false,
    }, ],
    participantCount: {
        type: Number,
        required: true,
    },
    totalPrice: {
        type: Number,
        required: true,
    },
    aboutThisTour: {
        type: String,
        required: true,
    },
    noOfDays: {
        type: Number,
        required: true,
    },
    dayPlan: [DayPlanSchema],
});

module.exports = mongoose.model("Tour", TourSchema);