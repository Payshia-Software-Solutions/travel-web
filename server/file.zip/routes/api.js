const express = require("express");
const router = express.Router();
const destinationController = require("../controllers/destination_controller");
const siteController = require("../controllers/site_controller");
const tourCategoryController = require("../controllers/tourCategoryController");
const tourController = require("../controllers/tourController");

// Destination Routes
router.post("/destinations", destinationController.createDestination);
router.get("/destinations", destinationController.getDestinations);
router.get("/destinations/:id", destinationController.getDestinationById);
router.put("/destinations/:id", destinationController.updateDestination);
router.delete("/destinations/:id", destinationController.deleteDestination);

// Site Routes
router.post("/sites", siteController.createSite);
router.get("/sites", siteController.getSites);
router.get("/sites/:id", siteController.getSiteById);
router.put("/sites/:id", siteController.updateSite);
router.delete("/sites/:id", siteController.deleteSite);

// Tour Category Routes
router.post("/tourcategories", tourCategoryController.createTourCategory);
router.get("/tourcategories", tourCategoryController.getTourCategories);
router.get("/tourcategories/:id", tourCategoryController.getTourCategoryById);
router.put("/tourcategories/:id", tourCategoryController.updateTourCategory);
router.delete("/tourcategories/:id", tourCategoryController.deleteTourCategory);

// Tour Routes
router.post("/tours", tourController.createTour);
router.get("/tours", tourController.getAllTours);
router.get("/tours/:id", tourController.getTourById);
router.put("/tours/:id", tourController.updateTour);
router.delete("/tours/:id", tourController.deleteTour);

module.exports = router;
